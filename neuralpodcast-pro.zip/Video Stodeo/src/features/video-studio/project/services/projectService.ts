import type { ClipNode, ProjectState, Track, TimelineTrackLaneRole } from '../types/project';
import { selectAllClips, selectClipById } from '../selectors/projectSelectors';
import { calculateProjectDuration, clampProjectTime } from '../../../../core/engine/projectDuration';
import { generateUUID } from '../../../../lib/uuid';
import { assertValidTimelineTracks } from '../validation';

export interface ProjectAssetInput {
  id: string;
  type?: string;
  name?: string;
  color?: string;
  thumbnail?: string;
  duration?: number;
  videoUrl?: string;
  audioUrl?: string;
  imageUrl?: string;
  textContent?: string;
  words?: unknown;
}

export function getAllClips(tracks: Track[]): ClipNode[] {
  return selectAllClips({ tracks });
}

export function getClipById(
  tracks: Track[],
  clipId: string,
): ClipNode | undefined {
  return selectClipById({ tracks }, clipId);
}

export function getActualDuration(
  tracks: Track[],
): number {
  return calculateProjectDuration(tracks);
}

export function normalizeCurrentTime(
  state: Pick<ProjectState, 'tracks' | 'currentTime'>,
): number {
  return clampProjectTime(
    state.currentTime,
    calculateProjectDuration(state.tracks),
  );
}

export function resolveAssetLaneRole(asset: ProjectAssetInput): TimelineTrackLaneRole {
  const declaredType = String(asset.type ?? '').toLowerCase();
  if (declaredType === 'audio') return 'audio';
  if (declaredType === 'caption') return 'caption';
  if (declaredType === 'text') return 'text';
  if (declaredType === 'sticker') return 'sticker';
  if (declaredType === 'effects') return 'effect';
  if (declaredType === 'transitions') return 'transition';
  if (declaredType === 'filters') return 'filter';
  if (declaredType === 'adjustments') return 'adjustment';
  if (declaredType === 'overlay') return 'overlay';
  if (declaredType === 'subscribe') return 'subscribe';
  if (declaredType === 'element') return 'element';
  if (declaredType === 'image' || Boolean(asset.imageUrl && !asset.videoUrl)) return 'image';
  return 'video';
}

function resolveTrackTypeForLaneRole(role: TimelineTrackLaneRole): Track['type'] {
  switch (role) {
    case 'audio': return 'audio';
    case 'caption':
    case 'text': return 'text';
    case 'sticker':
    case 'overlay':
    case 'subscribe':
    case 'effect':
    case 'transition':
    case 'filter':
    case 'adjustment':
    case 'element': return 'effect';
    case 'image':
    case 'video':
    default: return 'video';
  }
}

function nextDedicatedTrackName(tracks: readonly Track[], role: TimelineTrackLaneRole): string {
  const label = role.charAt(0).toUpperCase() + role.slice(1);
  const count = tracks.filter((track) => (track.laneRole ?? track.type) === role).length + 1;
  return `${label} ${count}`;
}

export function createDedicatedTimelineTrack(
  tracks: readonly Track[],
  role: TimelineTrackLaneRole,
  clip: ClipNode,
): Track[] {
  const trackType = resolveTrackTypeForLaneRole(role);
  const newTrack: Track = {
    id: generateUUID(),
    type: trackType,
    laneRole: role,
    name: nextDedicatedTrackName(tracks, role),
    isLocked: false,
    isMuted: false,
    isVisible: true,
    clips: [clip],
  };

  const nextTracks = [...tracks];
  const lastSameRole = nextTracks.reduce((last, track, index) => (
    (track.laneRole ?? track.type) === role ? index : last
  ), -1);

  nextTracks.splice(lastSameRole >= 0 ? lastSameRole + 1 : nextTracks.length, 0, newTrack);
  return nextTracks;
}

export function addAssetToTracks(
  tracks: Track[],
  asset: ProjectAssetInput,
  currentTime: number,
  cyberpunkDefaults: Record<string, unknown> = {},
): { tracks: Track[]; clipId: string; trackId: string; laneRole: TimelineTrackLaneRole } {
  const clipId = generateUUID();
  const laneRole = resolveAssetLaneRole(asset);
  const duration = Number.isFinite(asset.duration) && Number(asset.duration) > 0 ? Number(asset.duration) : 5;
  const isCaption = laneRole === 'caption';
  const properties: Record<string, unknown> = {
    name: asset.name,
    color: asset.color,
    thumbnail: asset.thumbnail,
    ...(asset.videoUrl ? { videoUrl: asset.videoUrl } : {}),
    ...(asset.audioUrl ? { audioUrl: asset.audioUrl } : {}),
    ...(asset.imageUrl ? { imageUrl: asset.imageUrl } : {}),
    ...(asset.textContent ? { textContent: asset.textContent } : {}),
    ...(asset.words ? { words: asset.words } : {}),
    timelineLaneRole: laneRole,
    sourceMediaDuration: duration,
    ...(laneRole === 'subscribe' || asset.id === 'st_cyber_sub' || asset.id === 'ef_cyber_sub'
      ? cyberpunkDefaults
      : {}),
  };

  const newClip: ClipNode = {
    id: clipId,
    sourceId: asset.id,
    startAt: Math.max(0, currentTime),
    duration,
    trim: { in: 0, out: duration },
    transform: isCaption
      ? { x: 0, y: 65, scale: 110, scaleX: 100, scaleY: 100, rotation: 0, opacity: 100 }
      : { x: 0, y: 0, scale: 100, scaleX: 100, scaleY: 100, rotation: 0, opacity: 100 },
    properties,
  };

  // Every insertion creates its own dedicated lane. This avoids unrelated
  // assets sharing one track and keeps overlap semantics deterministic.
  const nextTracks = createDedicatedTimelineTrack(tracks, laneRole, newClip);
  assertValidTimelineTracks(nextTracks);
  const trackId = nextTracks.find((track) => track.clips.some((clip) => clip.id === clipId))?.id;
  if (!trackId) throw new Error('Dedicated asset track was not materialized.');

  return { clipId, trackId, laneRole, tracks: nextTracks };
}

