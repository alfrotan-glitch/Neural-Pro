import type { ClipNode, Track, TimelineTrackLaneRole } from '../../project/types/project';

export interface CrossTrackDropResult {
  tracks: Track[];
  trackId: string;
  created: boolean;
}

function laneRoleOf(track: Track): TimelineTrackLaneRole | string {
  return track.laneRole ?? track.type;
}

/**
 * Resolves a single-clip cross-track move transaction.
 *
 * Rules:
 * - same semantic lane role is required for direct reuse of the destination;
 * - a locked destination rejects the transaction;
 * - a compatible destination track is used directly (no silent extra track);
 * - an incompatible destination is reported as null so the caller can decide
 *   whether a dedicated semantic lane must be materialized.
 */
export function placeSingleClipOnCrossTrackDrop(
  tracks: readonly Track[],
  clipId: string,
  sourceTrackId: string,
  requestedTrackId: string,
): CrossTrackDropResult | null {
  if (sourceTrackId === requestedTrackId) return null;

  const sourceTrack = tracks.find((track) => track.id === sourceTrackId);
  const requestedTrack = tracks.find((track) => track.id === requestedTrackId);
  if (!sourceTrack || !requestedTrack || requestedTrack.isLocked) return null;

  const clip = sourceTrack.clips.find((candidate) => candidate.id === clipId);
  if (!clip) return null;

  const sourceRole = laneRoleOf(sourceTrack);
  const requestedRole = laneRoleOf(requestedTrack);
  if (sourceRole !== requestedRole) return null;

  const nextTracks = tracks.map((track) => {
    if (track.id === sourceTrackId) {
      return { ...track, clips: track.clips.filter((candidate) => candidate.id !== clipId).map((clip) => structuredClone(clip)) };
    }
    if (track.id === requestedTrackId) {
      return { ...track, clips: [...track.clips.map((clip) => structuredClone(clip)), structuredClone(clip)] };
    }
    return { ...track, clips: track.clips.map((clip) => structuredClone(clip)) };
  });

  return { tracks: nextTracks, trackId: requestedTrackId, created: false };
}
