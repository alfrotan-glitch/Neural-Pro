import type { ClipNode, Track } from '../../project/types/project';

export type PreviewTransformMode = 'move' | 'resize' | 'rotate' | 'lineHeight' | 'letterSpacing';
export type ResizeHandle = 'nw' | 'ne' | 'sw' | 'se';

export interface PreviewPointerSnapshot {
  clientX: number;
  clientY: number;
  centerX: number;
  centerY: number;
  initialRadius: number;
  initialAngle: number;
  width: number;
  height: number;
  anchorX: number;
  anchorY: number;
  resizeHandle?: ResizeHandle;
  rotation: number;
}

export interface PreviewTransformOptions {
  magneticSnapping: boolean;
  shiftKey: boolean;
}

const MIN_SCALE = 10;
const MAX_SCALE = 400;
const SNAP_TRANSLATION = 1.75;
const SNAP_GUIDE_PX = 8;
const SNAP_ROTATION = 5;

function snapNearZero(value: number, threshold: number): number {
  return Math.abs(value) <= threshold ? 0 : value;
}

export function normalizeRotation(degrees: number): number {
  const value = ((degrees % 360) + 360) % 360;
  return value > 180 ? value - 360 : value;
}

export function snapRotation(
  degrees: number,
  enabled: boolean,
  threshold = SNAP_ROTATION,
): number {
  const normalized = normalizeRotation(degrees);
  const targets = [0, 90, -90, 180, -180];

  if (!enabled) return normalized;

  for (const target of targets) {
    if (Math.abs(normalized - target) <= threshold) {
      return target;
    }
  }

  return normalized;
}

export function getResizeHandleFromElement(
  handleRect: Pick<DOMRect, 'left' | 'top' | 'width' | 'height'>,
  parentRect: Pick<DOMRect, 'left' | 'top' | 'width' | 'height'>,
): ResizeHandle {
  const x = handleRect.left + handleRect.width / 2;
  const y = handleRect.top + handleRect.height / 2;
  const horizontal = x < parentRect.left + parentRect.width / 2 ? 'w' : 'e';
  const vertical = y < parentRect.top + parentRect.height / 2 ? 'n' : 's';
  return `${vertical}${horizontal}` as ResizeHandle;
}

export function createPointerSnapshot(
  startX: number,
  startY: number,
  bounds: DOMRect,
  resizeHandle?: ResizeHandle,
  geometry?: { width?: number; height?: number; rotation?: number },
): PreviewPointerSnapshot {
  const centerX = bounds.left + bounds.width / 2;
  const centerY = bounds.top + bounds.height / 2;
  const dx = startX - centerX;
  const dy = startY - centerY;

  const width = Math.max(1, geometry?.width ?? bounds.width);
  const height = Math.max(1, geometry?.height ?? bounds.height);
  const halfWidth = width / 2;
  const halfHeight = height / 2;
  const handle = resizeHandle ?? 'se';
  const anchorX = centerX + (handle.includes('w') ? halfWidth : -halfWidth);
  const anchorY = centerY + (handle.includes('n') ? halfHeight : -halfHeight);

  return {
    clientX: startX,
    clientY: startY,
    centerX,
    centerY,
    initialRadius: Math.max(1, Math.hypot(dx, dy)),
    initialAngle: Math.atan2(dy, dx),
    width,
    height,
    anchorX,
    anchorY,
    resizeHandle,
    rotation: geometry?.rotation ?? 0,
  };
}

export interface PreviewCanvasBounds {
  left: number;
  top: number;
  width: number;
  height: number;
}

function snapToGuide(value: number, guides: readonly number[], threshold: number): number {
  for (const guide of guides) {
    if (Math.abs(value - guide) <= threshold) return guide;
  }
  return value;
}

export function calculateMoveTransform(
  initialX: number,
  initialY: number,
  deltaX: number,
  deltaY: number,
  bounds: Pick<DOMRect, 'width' | 'height'>,
  options: PreviewTransformOptions,
  geometry?: { elementRect?: Pick<DOMRect, 'left' | 'top' | 'width' | 'height'>; canvasRect?: PreviewCanvasBounds },
): { x: number; y: number } {
  let dx = deltaX;
  let dy = deltaY;

  if (options.shiftKey) {
    if (Math.abs(dx) >= Math.abs(dy)) dy = 0;
    else dx = 0;
  }

  if (geometry?.elementRect && geometry.canvasRect) {
    const element = geometry.elementRect;
    const canvas = geometry.canvasRect;
    const minDx = canvas.left - element.left;
    const maxDx = canvas.left + canvas.width - (element.left + element.width);
    const minDy = canvas.top - element.top;
    const maxDy = canvas.top + canvas.height - (element.top + element.height);

    // When an element is larger than the canvas, keep its center in the canvas
    // rather than making the element impossible to move.
    if (minDx <= maxDx) dx = Math.min(maxDx, Math.max(minDx, dx));
    else dx = (canvas.left + canvas.width / 2) - (element.left + element.width / 2);

    if (minDy <= maxDy) dy = Math.min(maxDy, Math.max(minDy, dy));
    else dy = (canvas.top + canvas.height / 2) - (element.top + element.height / 2);

    if (options.magneticSnapping) {
      const centerX = element.left + element.width / 2 + dx;
      const centerY = element.top + element.height / 2 + dy;
      const snappedCenterX = snapToGuide(centerX, [
        canvas.left + canvas.width / 2,
        canvas.left + canvas.width * 0.25,
        canvas.left + canvas.width * 0.75,
      ], SNAP_GUIDE_PX);
      const snappedCenterY = snapToGuide(centerY, [
        canvas.top + canvas.height / 2,
        canvas.top + canvas.height * 0.25,
        canvas.top + canvas.height * 0.75,
      ], SNAP_GUIDE_PX);
      dx = Math.min(maxDx, Math.max(minDx, dx + (snappedCenterX - centerX)));
      dy = Math.min(maxDy, Math.max(minDy, dy + (snappedCenterY - centerY)));
    }
  }

  // ClipNode.transform.x/y are canonical pixel offsets from the canvas center.
  const x = initialX + dx;
  const y = initialY + dy;

  return {
    x: options.magneticSnapping ? snapNearZero(x, SNAP_TRANSLATION) : x,
    y: options.magneticSnapping ? snapNearZero(y, SNAP_TRANSLATION) : y,
  };
}

export interface AnchoredResizeResult {
  scale: number;
  scaleX: number;
  scaleY: number;
  centerX: number;
  centerY: number;
}

export function calculateAnchoredResize(
  initialScale: number,
  pointer: PreviewPointerSnapshot,
  clientX: number,
  clientY: number,
  canvasRect?: PreviewCanvasBounds,
  preserveAspect = true,
  initialScaleX = 100,
  initialScaleY = 100,
): AnchoredResizeResult {
  const rotationRad = (pointer.rotation * Math.PI) / 180;
  const cos = Math.cos(rotationRad);
  const sin = Math.sin(rotationRad);
  const worldDx = clientX - pointer.centerX;
  const worldDy = clientY - pointer.centerY;
  const localPointerX = worldDx * cos + worldDy * sin;
  const localPointerY = -worldDx * sin + worldDy * cos;
  const handle = pointer.resizeHandle ?? 'se';
  const hasHorizontal = handle.includes('w') || handle.includes('e');
  const hasVertical = handle.includes('n') || handle.includes('s');
  const anchorLocalX = handle.includes('w') ? pointer.width / 2 : -pointer.width / 2;
  const anchorLocalY = handle.includes('n') ? pointer.height / 2 : -pointer.height / 2;

  let widthRatio = 1;
  let heightRatio = 1;
  if (hasHorizontal) {
    const targetWidth = Math.max(4, 2 * Math.abs(localPointerX - anchorLocalX));
    widthRatio = targetWidth / Math.max(1, pointer.width);
  }
  if (hasVertical) {
    const targetHeight = Math.max(4, 2 * Math.abs(localPointerY - anchorLocalY));
    heightRatio = targetHeight / Math.max(1, pointer.height);
  }

  const cornerResize = hasHorizontal && hasVertical;
  if (preserveAspect && cornerResize) {
    const ratio = Math.max(0.01, Math.max(widthRatio, heightRatio));
    widthRatio = ratio;
    heightRatio = ratio;
  }

  const initialEffectiveX = Math.max(0.01, (initialScale / 100) * (initialScaleX / 100));
  const initialEffectiveY = Math.max(0.01, (initialScale / 100) * (initialScaleY / 100));
  let nextEffectiveX = initialEffectiveX * widthRatio;
  let nextEffectiveY = initialEffectiveY * heightRatio;

  if (canvasRect) {
    const baseHalfW = pointer.width / 2;
    const baseHalfH = pointer.height / 2;
    const anchorWorldX = pointer.centerX + anchorLocalX * cos - anchorLocalY * sin;
    const anchorWorldY = pointer.centerY + anchorLocalX * sin + anchorLocalY * cos;
    const fits = (effectiveX: number, effectiveY: number) => {
      const halfW = baseHalfW * (effectiveX / initialEffectiveX);
      const halfH = baseHalfH * (effectiveY / initialEffectiveY);
      const centerLocalX = anchorLocalX + (handle.includes('w') || !hasHorizontal ? -halfW : halfW);
      const centerLocalY = anchorLocalY + (handle.includes('n') || !hasVertical ? -halfH : halfH);
      const centerWorldX = anchorWorldX + (centerLocalX - anchorLocalX) * cos - (centerLocalY - anchorLocalY) * sin;
      const centerWorldY = anchorWorldY + (centerLocalX - anchorLocalX) * sin + (centerLocalY - anchorLocalY) * cos;
      for (const [cx, cy] of [[-halfW, -halfH], [halfW, -halfH], [-halfW, halfH], [halfW, halfH]] as const) {
        const x = centerWorldX + cx * cos - cy * sin;
        const y = centerWorldY + cx * sin + cy * cos;
        if (x < canvasRect.left - 0.5 || x > canvasRect.left + canvasRect.width + 0.5 ||
            y < canvasRect.top - 0.5 || y > canvasRect.top + canvasRect.height + 0.5) return false;
      }
      return true;
    };
    if (!fits(nextEffectiveX, nextEffectiveY)) {
      const startX = initialEffectiveX;
      const startY = initialEffectiveY;
      let low = 0.01;
      let high = 1;
      for (let i = 0; i < 22; i += 1) {
        const mid = (low + high) / 2;
        const testX = preserveAspect && cornerResize ? startX + (nextEffectiveX - startX) * mid : nextEffectiveX;
        const testY = preserveAspect && cornerResize ? startY + (nextEffectiveY - startY) * mid : nextEffectiveY;
        if (fits(testX, testY)) low = mid;
        else high = mid;
      }
      if (preserveAspect && cornerResize) {
        nextEffectiveX = startX + (nextEffectiveX - startX) * low;
        nextEffectiveY = startY + (nextEffectiveY - startY) * low;
      } else {
        if (!fits(nextEffectiveX, nextEffectiveY)) {
          if (hasHorizontal) nextEffectiveX = Math.min(nextEffectiveX, startX);
          if (hasVertical) nextEffectiveY = Math.min(nextEffectiveY, startY);
        }
      }
    }
  }

  const widthScaleRatio = nextEffectiveX / initialEffectiveX;
  const heightScaleRatio = nextEffectiveY / initialEffectiveY;
  const halfWidth = pointer.width * widthScaleRatio / 2;
  const halfHeight = pointer.height * heightScaleRatio / 2;
  const centerLocalX = hasHorizontal
    ? anchorLocalX + (handle.includes('w') ? -halfWidth : halfWidth)
    : 0;
  const centerLocalY = hasVertical
    ? anchorLocalY + (handle.includes('n') ? -halfHeight : halfHeight)
    : 0;
  const anchorWorldX = pointer.centerX + anchorLocalX * cos - anchorLocalY * sin;
  const anchorWorldY = pointer.centerY + anchorLocalX * sin + anchorLocalY * cos;
  const centerX = anchorWorldX + (centerLocalX - anchorLocalX) * cos - (centerLocalY - anchorLocalY) * sin;
  const centerY = anchorWorldY + (centerLocalX - anchorLocalX) * sin + (centerLocalY - anchorLocalY) * cos;

  const uniformRatio = Math.sqrt(Math.max(0.0001, widthScaleRatio * heightScaleRatio));
  const scale = cornerResize
    ? Math.max(MIN_SCALE, Math.min(MAX_SCALE, initialScale * uniformRatio))
    : Math.max(MIN_SCALE, Math.min(MAX_SCALE, initialScale));
  const scaleX = cornerResize
    ? Math.max(MIN_SCALE, Math.min(MAX_SCALE, initialScaleX))
    : Math.max(MIN_SCALE, Math.min(MAX_SCALE, initialScaleX * widthScaleRatio));
  const scaleY = cornerResize
    ? Math.max(MIN_SCALE, Math.min(MAX_SCALE, initialScaleY))
    : Math.max(MIN_SCALE, Math.min(MAX_SCALE, initialScaleY * heightScaleRatio));
  return { scale, scaleX, scaleY, centerX, centerY };
}

export function calculateScale(
  initialScale: number,
  pointer: PreviewPointerSnapshot,
  clientX: number,
  clientY: number,
): number {
  return calculateAnchoredResize(initialScale, pointer, clientX, clientY).scale;
}

export function calculateRotation(
  initialRotation: number,
  pointer: PreviewPointerSnapshot,
  clientX: number,
  clientY: number,
  options: PreviewTransformOptions,
): number {
  const angle = Math.atan2(
    clientY - pointer.centerY,
    clientX - pointer.centerX,
  );
  const delta = ((angle - pointer.initialAngle) * 180) / Math.PI;
  return snapRotation(
    initialRotation + delta,
    options.magneticSnapping || options.shiftKey,
    options.shiftKey ? 15 : SNAP_ROTATION,
  );
}

export function isTrackLocked(
  tracks: readonly Track[],
  clipId: string,
): boolean {
  return Boolean(
    tracks.find((track) =>
      track.clips.some((clip) => clip.id === clipId),
    )?.isLocked,
  );
}

export function applyMoveToClips(
  tracks: readonly Track[],
  originalClips: ReadonlyMap<string, { transform: ClipNode['transform']; properties: ClipNode['properties'] }>,
  primaryClipId: string,
  deltaX: number,
  deltaY: number,
  bounds: Pick<DOMRect, 'width' | 'height'>,
  options: PreviewTransformOptions,
  geometry?: { elementRect?: Pick<DOMRect, 'left' | 'top' | 'width' | 'height'>; canvasRect?: PreviewCanvasBounds },
): Track[] {
  const primary = originalClips.get(primaryClipId);
  if (!primary) return tracks.map((track) => ({ ...track, clips: [...track.clips] }));

  const delta = calculateMoveTransform(
    primary.transform.x,
    primary.transform.y,
    deltaX,
    deltaY,
    bounds,
    options,
    geometry,
  );

  const offsetX = delta.x - primary.transform.x;
  const offsetY = delta.y - primary.transform.y;

  return tracks.map((track) => ({
    ...track,
    clips: track.clips.map((clip) => {
      const original = originalClips.get(clip.id);
      if (!original) return clip;

      return {
        ...clip,
        transform: {
          ...clip.transform,
          x: original.transform.x + offsetX,
          y: original.transform.y + offsetY,
        },
        properties: { ...clip.properties },
      };
    }),
  }));
}

export function applyScaleToClips(
  tracks: readonly Track[],
  originalClips: ReadonlyMap<string, { transform: ClipNode['transform']; properties: ClipNode['properties'] }>,
  primaryClipId: string,
  scale: number,
): Track[] {
  const primary = originalClips.get(primaryClipId);
  if (!primary) return tracks.map((track) => ({ ...track, clips: [...track.clips] }));

  const ratio = scale / Math.max(MIN_SCALE, primary.transform.scale || 100);

  return tracks.map((track) => ({
    ...track,
    clips: track.clips.map((clip) => {
      const original = originalClips.get(clip.id);
      if (!original) return clip;

      return {
        ...clip,
        transform: {
          ...clip.transform,
          scale: Math.max(
            MIN_SCALE,
            Math.min(MAX_SCALE, (original.transform.scale || 100) * ratio),
          ),
        },
        properties: { ...clip.properties },
      };
    }),
  }));
}

function getTransformGroupCenter(
  originalClips: ReadonlyMap<string, { transform: ClipNode['transform']; properties: ClipNode['properties'] }>,
): { x: number; y: number; count: number } {
  let x = 0;
  let y = 0;
  let count = 0;
  for (const original of originalClips.values()) {
    x += original.transform.x;
    y += original.transform.y;
    count += 1;
  }
  if (!count) return { x: 0, y: 0, count: 0 };
  return { x: x / count, y: y / count, count };
}

export function applyAnchoredResizeToClips(
  tracks: readonly Track[],
  originalClips: ReadonlyMap<string, { transform: ClipNode['transform']; properties: ClipNode['properties'] }>,
  primaryClipId: string,
  initialScale: number,
  pointer: PreviewPointerSnapshot,
  clientX: number,
  clientY: number,
  canvasRect?: PreviewCanvasBounds,
  multiSelection = false,
  preserveAspect = true,
): Track[] {
  const primary = originalClips.get(primaryClipId);
  if (!primary) return tracks.map((track) => ({ ...track, clips: [...track.clips] }));

  const initialScaleX = primary.transform.scaleX || 100;
  const initialScaleY = primary.transform.scaleY || 100;
  const result = calculateAnchoredResize(initialScale, pointer, clientX, clientY, canvasRect, preserveAspect, initialScaleX, initialScaleY);
  const deltaX = result.centerX - pointer.centerX;
  const deltaY = result.centerY - pointer.centerY;
  const scaleRatio = result.scale / Math.max(MIN_SCALE, initialScale);
  const axisScaleXRatio = result.scaleX / Math.max(MIN_SCALE, initialScaleX);
  const axisScaleYRatio = result.scaleY / Math.max(MIN_SCALE, initialScaleY);
  const geometryScaleXRatio = scaleRatio * axisScaleXRatio;
  const geometryScaleYRatio = scaleRatio * axisScaleYRatio;

  const group = getTransformGroupCenter(originalClips);
  const groupCenterX = group.count > 1 ? group.x : primary.transform.x;
  const groupCenterY = group.count > 1 ? group.y : primary.transform.y;
  // The resize result reports how far the primary element's center moved while
  // preserving its opposite-corner anchor. A multi-selection must translate
  // the whole group by that same center delta; subtracting the primary's
  // offset from the group center double-counts the offset and causes a jump.
  const groupDeltaX = deltaX;
  const groupDeltaY = deltaY;

  return tracks.map((track) => ({
    ...track,
    clips: track.clips.map((clip) => {
      const original = originalClips.get(clip.id);
      if (!original) return clip;

      return {
        ...clip,
        transform: {
          ...clip.transform,
          x: multiSelection
            ? groupCenterX + (original.transform.x - groupCenterX) * geometryScaleXRatio + groupDeltaX
            : original.transform.x + deltaX,
          y: multiSelection
            ? groupCenterY + (original.transform.y - groupCenterY) * geometryScaleYRatio + groupDeltaY
            : original.transform.y + deltaY,
          scale: Math.max(MIN_SCALE, Math.min(MAX_SCALE, (original.transform.scale || 100) * scaleRatio)),
          scaleX: Math.max(MIN_SCALE, Math.min(MAX_SCALE, (original.transform.scaleX || 100) * axisScaleXRatio)),
          scaleY: Math.max(MIN_SCALE, Math.min(MAX_SCALE, (original.transform.scaleY || 100) * axisScaleYRatio)),
        },
        properties: { ...clip.properties },
      };
    }),
  }));
}

export function applyRotationToClips(
  tracks: readonly Track[],
  originalClips: ReadonlyMap<string, { transform: ClipNode['transform']; properties: ClipNode['properties'] }>,
  primaryClipId: string,
  rotation: number,
  multiSelection = false,
): Track[] {
  const primary = originalClips.get(primaryClipId);
  if (!primary) return tracks.map((track) => ({ ...track, clips: [...track.clips] }));

  const delta = normalizeRotation(rotation - (primary.transform.rotation || 0));
  const angleRad = (delta * Math.PI) / 180;
  const cos = Math.cos(angleRad);
  const sin = Math.sin(angleRad);
  const group = getTransformGroupCenter(originalClips);
  const groupCenterX = group.count > 1 ? group.x : primary.transform.x;
  const groupCenterY = group.count > 1 ? group.y : primary.transform.y;

  return tracks.map((track) => ({
    ...track,
    clips: track.clips.map((clip) => {
      const original = originalClips.get(clip.id);
      if (!original) return clip;

      return {
        ...clip,
        transform: {
          ...clip.transform,
          x: multiSelection
            ? groupCenterX + ((original.transform.x - groupCenterX) * cos - (original.transform.y - groupCenterY) * sin)
            : original.transform.x,
          y: multiSelection
            ? groupCenterY + ((original.transform.x - groupCenterX) * sin + (original.transform.y - groupCenterY) * cos)
            : original.transform.y,
          rotation: normalizeRotation((original.transform.rotation || 0) + delta),
        },
        properties: { ...clip.properties },
      };
    }),
  }));
}
