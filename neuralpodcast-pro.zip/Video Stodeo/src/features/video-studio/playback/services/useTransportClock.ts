import { useSyncExternalStore } from 'react';
import { TransportClock } from './transportClock';

let transportClock: TransportClock | null = null;

export function getTransportClock(): TransportClock {
  if (!transportClock) {
    transportClock = new TransportClock({ publishFps: 30 });
  }
  return transportClock;
}

export function useTransportTime(): number {
  const clock = getTransportClock();
  return useSyncExternalStore(
    (listener) => clock.subscribe(() => listener()),
    () => clock.currentTime,
    () => clock.currentTime,
  );
}
