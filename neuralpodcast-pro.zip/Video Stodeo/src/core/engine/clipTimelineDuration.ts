/**
 * Canonical Timeline duration calculation for a single clip.
 *
 * A Clip's declared timeline duration may not exceed the source range exposed
 * by trim.in/trim.out after playback-rate mapping.
 *
 * This module is intentionally dependency-light so Project Duration, Preview,
 * Playback, Audio and Export can all use the same duration rule without
 * creating a feature/core import cycle.
 */

const DEFAULT_SPEED = 1;
const MIN_SPEED = 0.0625;
const MAX_SPEED = 16;

type ClipLike = {
  duration: number;
  trim?: { in?: number; out?: number } | null;
  properties?: { speed?: unknown } | null;
};

export function getCanonicalClipPlaybackRate(clip: ClipLike): number {
  const raw = Number(clip.properties?.speed);
  if (!Number.isFinite(raw) || raw <= 0) return DEFAULT_SPEED;
  return Math.min(MAX_SPEED, Math.max(MIN_SPEED, raw));
}

export function getCanonicalClipSourceDuration(clip: ClipLike): number | null {
  const start = Number.isFinite(clip.trim?.in) ? Math.max(0, Number(clip.trim?.in)) : 0;
  const rawEnd = Number.isFinite(clip.trim?.out) ? Number(clip.trim?.out) : NaN;
  if (!Number.isFinite(rawEnd) || rawEnd <= start) return null;
  return Math.max(0, rawEnd - start);
}

export function getCanonicalClipTimelineDuration(clip: ClipLike): number {
  const declaredDuration = Math.max(0, Number.isFinite(clip.duration) ? clip.duration : 0);
  const sourceDuration = getCanonicalClipSourceDuration(clip);
  if (sourceDuration === null) return declaredDuration;

  return Math.min(
    declaredDuration,
    sourceDuration / getCanonicalClipPlaybackRate(clip),
  );
}
